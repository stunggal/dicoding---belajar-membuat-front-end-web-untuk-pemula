# Dicoding-Movie-List
Submission: Membuat Aplikasi Web dengan ES6, Custom Element, NPM, Webpack, dan AJAX
